// Variables globales o funciones que necesites
var contadorCondicionesSalud = 0;

function agregarCondicionSalud() {
    contadorCondicionesSalud++;

    var condicionesSaludContainer = document.getElementById("condicionesSaludContainer");
    var nuevaCondicionSalud = document.createElement("div");
    nuevaCondicionSalud.innerHTML = `
        <label for="condicionSalud${contadorCondicionesSalud}">Condición de Salud:</label>
        <input type="text" id="condicionSalud${contadorCondicionesSalud}" name="condicionSalud${contadorCondicionesSalud}">
        <!-- Otros campos de condiciones de salud -->
    `;
    condicionesSaludContainer.appendChild(nuevaCondicionSalud);
}

function guardarCondicionesSalud() {
    // Aquí puedes obtener los datos de los campos dinámicos y guardarlos como desees
    var condicionesSalud = [];

    for (var i = 1; i <= contadorCondicionesSalud; i++) {
        var condicion = document.getElementById("condicionSalud" + i).value;

        // Aquí puedes hacer lo que necesites con los datos, como enviarlos a un servidor o guardarlos localmente
        condicionesSalud.push(condicion);
    }

    // Ejemplo de mostrar los datos en consola
    console.log("Condiciones de Salud Guardadas:", condicionesSalud);
}
