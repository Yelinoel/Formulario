// Función para cargar y mostrar los datos guardados en la tabla
function mostrarDatosEnTabla() {
    // Obtener los datos guardados del localStorage
    var datosGuardados = localStorage.getItem('datosPersonales');

    // Verificar si hay datos guardados
    if (datosGuardados) {
        // Convertir los datos de JSON a objeto JavaScript
        var datosPersonales = JSON.parse(datosGuardados);

        // Crear filas y celdas para mostrar los datos en la tabla
        var tabla = document.getElementById('dataTable');
        var fila = tabla.insertRow();
        var celdaNombre = fila.insertCell(0);
        var celdaApellido = fila.insertCell(1);
        // Agregar más celdas según sea necesario

        // Asignar los valores de los datos a las celdas
        celdaNombre.textContent = datosPersonales.nombre;
        celdaApellido.textContent = datosPersonales.apellido;
        // Asignar más valores a las celdas según sea necesario
    }
}

// Llamar a la función para mostrar los datos en la tabla cuando la página se cargue completamente
window.onload = function() {
    mostrarDatosEnTabla();
};
