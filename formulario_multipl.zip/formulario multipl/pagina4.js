// Variables globales o funciones que necesites
var contadorInternamientos = 0;

function agregarInternamiento() {
    contadorInternamientos++;

    var internamientosContainer = document.getElementById("internamientosContainer");
    var nuevoInternamiento = document.createElement("div");
    nuevoInternamiento.innerHTML = `
        <label for="internamiento${contadorInternamientos}">Internamiento:</label>
        <input type="text" id="internamiento${contadorInternamientos}" name="internamiento${contadorInternamientos}">
        <!-- Otros campos de internamientos -->
    `;
    internamientosContainer.appendChild(nuevoInternamiento);
}

function guardarInternamientos() {
    // Aquí puedes obtener los datos de los campos dinámicos y guardarlos como desees
    var internamientos = [];

    for (var i = 1; i <= contadorInternamientos; i++) {
        var internamiento = document.getElementById("internamiento" + i).value;

        // Aquí puedes hacer lo que necesites con los datos, como enviarlos a un servidor o guardarlos localmente
        internamientos.push(internamiento);
    }

    // Ejemplo de mostrar los datos en consola
    console.log("Internamientos Guardados:", internamientos);
}
