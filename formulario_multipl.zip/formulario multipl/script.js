// script.js
let formData = {}; // Objeto JSON para almacenar los datos del formulario


// Función para guardar los datos personales en el almacenamiento local
function guardarDatosPersonales() {
    // Obtener los valores de los campos del formulario
    var nombre = document.getElementById('nombre').value;
    var apellido = document.getElementById('apellido').value;
    // Obtener otros valores de campos de datos personales según sea necesario

    // Crear un objeto con los datos recolectados
    var datosPersonales = {
        nombre: nombre,
        apellido: apellido
        // Agregar otros campos aquí si es necesario
    };

    // Convertir el objeto a formato de cadena JSON
    var datosPersonalesJSON = JSON.stringify(datosPersonales);

    // Guardar los datos en el almacenamiento local del navegador
    localStorage.setItem('datosPersonales', datosPersonalesJSON);

    // Limpiar los campos del formulario después de guardar
    document.getElementById('nombre').value = '';
    document.getElementById('apellido').value = '';
    // Limpiar otros campos del formulario según sea necesario

    // Mostrar mensaje de éxito o realizar otra acción después de guardar
    alert('Datos personales guardados correctamente.');
}



function cargarDatosGuardados() {
    // Verificar si hay datos guardados en el almacenamiento local
    if (localStorage.getItem('datosPersonales')) {
        // Obtener los datos guardados del almacenamiento local y convertirlos de nuevo a un objeto JavaScript
        var datosPersonalesJSON = localStorage.getItem('datosPersonales');
        var datosPersonales = JSON.parse(datosPersonalesJSON);

        // Mostrar los datos en la tabla
        var tabla = document.getElementById('dataTable').getElementsByTagName('tbody')[0];
        var fila = tabla.insertRow();
        var celdaNombre = fila.insertCell(0);
        var celdaApellido = fila.insertCell(1);
        celdaNombre.innerHTML = datosPersonales.nombre;
        celdaApellido.innerHTML = datosPersonales.apellido;
    }
}

// Llamar a la función para cargar los datos guardados cuando la página se cargue
window.onload = function() {
    window.location.href = 'tabla.html'();
};

function mostrarDatosEnTabla() {
    const dataTable = document.getElementById('dataTable');
    dataTable.innerHTML = `
        <tr>
            <td>${formData.nombre}</td>
            <td>${formData.apellido}</td>
        </tr>
    `;
}
function calcularEdad() {
    var fechaNacimiento = new Date(document.getElementById("fechaNacimiento").value);
    var hoy = new Date();
    var edad = hoy.getFullYear() - fechaNacimiento.getFullYear();
    var mes = hoy.getMonth() - fechaNacimiento.getMonth();

    if (mes < 0 || (mes === 0 && hoy.getDate() < fechaNacimiento.getDate())) {
        edad--;
    }

    document.getElementById("edad").value = edad;
}

function editar() {
    // Redireccionar al inicio del formulario para editar
    window.location.href = 'index.html';
}

// Llamar a cargarDatos al cargar la página
window.onload = cargarDatosGuardados;


