// Variables globales o funciones que necesites
var contadorFamiliares = 0;

function agregarFamiliar() {
    contadorFamiliares++;

    var familiaresContainer = document.getElementById("familiaresContainer");
    var nuevoFamiliar = document.createElement("div");
    nuevoFamiliar.innerHTML = `
        <label for="familiarNombre${contadorFamiliares}">Nombre:</label>
        <input type="text" id="familiarNombre${contadorFamiliares}" name="familiarNombre${contadorFamiliares}">
        <label for="familiarParentesco${contadorFamiliares}">Parentesco:</label>
        <input type="text" id="familiarParentesco${contadorFamiliares}" name="familiarParentesco${contadorFamiliares}">
        <!-- Otros campos de datos familiares -->
    `;
    familiaresContainer.appendChild(nuevoFamiliar);
}

function guardarFamiliares() {
    // Aquí puedes obtener los datos de los campos dinámicos y guardarlos como desees
    var datosFamiliares = [];

    for (var i = 1; i <= contadorFamiliares; i++) {
        var nombre = document.getElementById("familiarNombre" + i).value;
        var parentesco = document.getElementById("familiarParentesco" + i).value;

        // Aquí puedes hacer lo que necesites con los datos, como enviarlos a un servidor o guardarlos localmente
        datosFamiliares.push({ nombre: nombre, parentesco: parentesco });
    }

    // Ejemplo de mostrar los datos en consola
    console.log("Datos Familiares Guardados:", datosFamiliares);
}
